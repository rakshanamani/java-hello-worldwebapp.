# Java Hello World Web Application

A minimal Maven WAR application for Apache Tomcat 11.

## Build
Run from this folder:

```bash
mvn clean package
```

The WAR file will be created at `target/java-hello-world-webapp.war`.

## Run on Tomcat 11
Deploy the WAR to Tomcat's `webapps` folder, start Tomcat, then open:

- `http://localhost:8080/java-hello-world-webapp/`
- `http://localhost:8080/java-hello-world-webapp/hello`

If your Tomcat uses a different port, replace `8080` with that port.
